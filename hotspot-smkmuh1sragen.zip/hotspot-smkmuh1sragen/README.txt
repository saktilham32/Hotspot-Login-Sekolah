========================================================
 TEMPLATE LOGIN HOTSPOT — SMK MUHAMMADIYAH 1 SRAGEN
 Untuk MikroTik RouterOS Hotspot
========================================================

ISI PAKET
---------
login.html      Halaman login utama (form username & password)
alogin.html     Halaman "berhasil login"
status.html     Halaman status koneksi (kuota, uptime, MAC, dll)
logout.html     Halaman setelah logout + ringkasan sesi
error.html      Halaman kesalahan
rlogin.html     Redirect ke halaman login (jangan diubah)
redirect.html   Redirect umum (jangan diubah)
flogout.html    Redirect setelah logout
md5.js          Library MD5 untuk autentikasi CHAP
errors.txt      Pesan error versi Bahasa Indonesia (opsional)
css/style.css   Seluruh tampilan (tanpa Bootstrap / tanpa CDN)
img/logo.svg    Logo sementara — GANTI dengan logo resmi sekolah


CARA PASANG
-----------
1. Buka Winbox > Files.
2. Backup dulu folder "hotspot" bawaan router (drag ke komputer).
3. Drag seluruh isi folder ini ke dalam folder "hotspot" di router,
   timpa file yang namanya sama.
   PENTING: struktur folder css/ dan img/ harus ikut terbawa.
4. Pastikan profil hotspot memakai directory tersebut:
   /ip hotspot profile set [find] html-directory=hotspot
5. Putuskan koneksi klien, lalu buka browser — halaman login baru muncul.

Lewat terminal (alternatif, file sudah diupload ke router):
   /ip hotspot profile set [find name=hsprof1] html-directory=hotspot


LOGO SEKOLAH
------------
Sudah pakai logo resmi (img/logo.png) — latar belakang putihnya
sudah dihapus (transparan) dan gambarnya dihaluskan/dipertajam dari
file asli yang beresolusi kecil.

Kalau nanti punya file logo baru yang lebih tinggi resolusinya:
1. Siapkan PNG idealnya transparan, minimal lebar 300px.
2. Upload ke folder hotspot/img/, timpa nama file logo.png.
3. Tidak perlu ubah HTML apa pun — semua halaman sudah memanggil
   img/logo.png. Bentuk logo perisai (tidak kotak/bulat) sudah
   diperhitungkan di css/style.css (object-fit: contain), jadi
   logo dengan proporsi berbeda pun tidak akan gepeng.


GANTI WARNA
-----------
Buka css/style.css, bagian paling atas ada blok :root.
Ubah nilai warna di sana, semua halaman ikut berubah:
   --brand-dark  warna navbar & footer (hijau tua)
   --orange      garis aksen di bawah navbar
   --brand       warna tombol "Masuk" (hijau)
   --teal        menu aktif (biru toska)
   --grad-a/b/c  gradasi banner: biru > toska > hijau limau
   --maroon      pita merah bata di bawah banner


UBAH TEKS / IDENTITAS
---------------------
- Judul banner: cari  HOTSPOT SMK MUHAMMADIYAH 1 SRAGEN
- Alamat sekolah: ada di baris <p> tepat di bawah judul banner
- Motto, telepon, email, alamat: di bagian <div class="card"> tiap halaman
- Link Facebook / Website / Instagram: di <div class="bottom">,
  ganti href="#" dengan alamat resmi sekolah


CATATAN TEKNIS
--------------
- Nama field WAJIB tetap name="username" dan name="password",
  serta hidden input dst & popup — jangan diubah.
- Blok $(if ...) ... $(endif) adalah sintaks RouterOS. Blok tersebut
  tidak akan tampil benar bila file dibuka langsung di browser;
  itu normal. Gunakan file preview terpisah untuk melihat tampilan.
- Bila hotspot profile memakai login method HTTP CHAP, md5.js harus
  ikut terupload, kalau tidak login akan selalu gagal.
- Template ini tidak memanggil CDN apa pun, jadi tetap tampil rapi
  walaupun klien belum punya akses internet.


UJI RESPONSIF (sudah dilakukan)
-------------------------------
Halaman diuji otomatis pada 10 ukuran layar, semua tanpa scroll
menyamping dan tombol "Masuk" selalu terlihat tanpa perlu scroll:

  Desktop 1366x768 ............ OK
  Laptop 1024x700 ............. OK
  iPad portrait 768x1024 ...... OK
  iPad landscape 1024x768 ..... OK
  Android 412x915 ............. OK
  Android 360x740 ............. OK
  iPhone SE 375x667 ........... OK
  iPhone 14 390x844 ........... OK
  Popup captive portal 320x480  OK
  HP landscape 740x360 ........ OK

Penyesuaian khusus perangkat:
- Input memakai font 16px. Di bawah itu Safari iOS otomatis melakukan
  zoom saat kolom diketik, dan halaman jadi "melompat".
- Tombol minimal tinggi 48px agar nyaman disentuh.
- Nama hotspot panjang di navbar dipotong (...) supaya tidak melipat
  jadi dua baris di layar sempit.
- Pada layar pendek (HP landscape / jendela captive portal), banner
  dan sapaan selamat datang dirapatkan otomatis supaya form login
  tidak terdorong ke bawah layar. Pesan error TIDAK ikut disembunyikan.
- Pinch-to-zoom tetap diizinkan (tidak dikunci maximum-scale), supaya
  pengguna dengan penglihatan terbatas masih bisa memperbesar.
